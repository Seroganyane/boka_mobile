# House-call distance and pricing

The booking form offers **Come to us** (no travel fee) and **House call** (R5/km for one-way driving distance from 6385 Mothomo Crescent, Birch Acres, Kempton Park, South Africa).

The form calculates after the customer pauses typing a full address. It displays distance in kilometres, the travel fee, the package price and the total. For example, a 12.5 km journey adds R62.50; a R700 package totals R762.50. Distance uses metres returned by the routing service; the fee is rounded to the nearest cent.

## Activate on HOSTAFRICA

1. In Google Cloud, enable billing and the **Routes API**, then create a server API key. Restrict the key to the Routes API and your hosting server's outbound IP address. Set suitable API quotas in Google Cloud. See [Google's Routes API setup](https://developers.google.com/maps/documentation/routes/get-api-key).
2. Add these entries to the existing private `boka-config.php` **above** `public_html` (keep the current payment, email and database settings):

   ```php
   'BUSINESS_ADDRESS' => '6385 Mothomo Crescent, Birch Acres, Kempton Park, South Africa',
   'GOOGLE_MAPS_API_KEY' => 'your_server_routes_api_key',
   'TRAVEL_QUOTE_SECRET' => 'your_random_secret_of_at_least_32_characters',
   ```

   Generate the signing secret with `php -r "echo bin2hex(random_bytes(32));"`. Keep it private and stable: it also verifies travel charges when payment notifications arrive.
3. Upload the updated `index.html`, `css`, `js` and **all** `php` files together. PHP cURL and outbound HTTPS must be enabled. No database schema change is required: visit type, distance and travel charge are stored in booking notes and included in confirmation emails.
4. Test a known nearby full address and confirm the route starts at the correct property before accepting house calls. Check both cash and PayFast sandbox bookings, including their totals and emails.

Without the maps key and signing secret, customers can still select **Come to us**. House-call quotes show an unavailable message and cannot be submitted without a valid quote; they never silently receive free travel.

Quotes expire after 30 minutes. Changing the address clears the quote immediately. The server verifies the signed distance and calculates the full amount independently for both payment methods. PayFast notifications verify the travel charge before accepting the payment.

Local checks: `php tests/travel-pricing-test.php` and `node --test tests/booking-travel.test.cjs`. These use simulated distances; live routing and payment confirmation still require server credentials.
