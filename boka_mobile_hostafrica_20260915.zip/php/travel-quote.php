<?php
declare(strict_types=1);
require_once __DIR__ . '/travel-pricing.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function quoteResponse(int $status, array $data): void
{
    http_response_code($status);
    echo json_encode($data);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') quoteResponse(405, ['message' => 'Method not allowed.']);
$input = json_decode((string) file_get_contents('php://input'), true);
$location = is_array($input) && is_string($input['location'] ?? null) ? trim($input['location']) : '';
if (strlen($location) < 10 || strlen($location) > 200) quoteResponse(422, ['message' => 'Enter your full street address, suburb and town.']);

try {
    travelSecret();
    $key = configValue('GOOGLE_MAPS_API_KEY');
    if ($key === '' || !function_exists('curl_init')) throw new RuntimeException('House-call distance lookup is unavailable. Please call us to book.');
    $curl = curl_init('https://routes.googleapis.com/directions/v2:computeRoutes');
    curl_setopt_array($curl, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'X-Goog-Api-Key: ' . $key, 'X-Goog-FieldMask: routes.distanceMeters'],
        CURLOPT_POSTFIELDS => json_encode([
            'origin' => ['address' => businessAddress()],
            'destination' => ['address' => $location],
            'travelMode' => 'DRIVE',
            'routingPreference' => 'TRAFFIC_UNAWARE',
            'regionCode' => 'ZA',
            'units' => 'METRIC',
        ]),
    ]);
    $response = curl_exec($curl);
    $status = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);
    if ($response === false || $status !== 200) throw new RuntimeException('We could not calculate the route. Check your full address and try again, or call us to book.');
    $data = json_decode($response, true);
    $meters = $data['routes'][0]['distanceMeters'] ?? null;
    if (!is_int($meters) || $meters < 0) throw new RuntimeException('No driving route was found. Please check your full address or call us to book.');
    quoteResponse(200, [
        'distanceKm' => $meters / 1000,
        'feeCents' => travelFeeCents($meters),
        'quote' => signTravelQuote($location, $meters),
        'expiresAt' => time() + 1800,
    ]);
} catch (RuntimeException $error) {
    quoteResponse(503, ['message' => $error->getMessage()]);
}
