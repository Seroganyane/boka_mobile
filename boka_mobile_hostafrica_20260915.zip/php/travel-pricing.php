<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';

function businessAddress(): string
{
    return configValue('BUSINESS_ADDRESS', '6385 Mothomo Crescent, Birch Acres, Kempton Park, South Africa');
}

function travelSecret(): string
{
    $secret = configValue('TRAVEL_QUOTE_SECRET');
    if (strlen($secret) < 32) throw new RuntimeException('House-call quotes are not configured yet. Please call us to book.');
    return $secret;
}

function travelFeeCents(int $meters): int
{
    // R5/km, rounded once to the nearest cent, using the full distance in metres.
    return (int) round($meters / 2);
}

function signTravelQuote(string $location, int $meters): string
{
    $payload = base64_encode(json_encode(['location' => $location, 'meters' => $meters, 'expires' => time() + 1800]));
    return $payload . '.' . hash_hmac('sha256', $payload, travelSecret());
}

function bookingTravel(array $input): array
{
    $type = (string) ($input['visitType'] ?? '');
    if ($type === 'dropoff') return ['type' => $type, 'location' => businessAddress(), 'meters' => 0, 'feeCents' => 0];
    if ($type !== 'housecall') throw new InvalidArgumentException('Please choose whether you are coming to us or need a house call.');
    $location = trim((string) ($input['location'] ?? ''));
    $parts = explode('.', (string) ($input['travelQuote'] ?? ''));
    if (count($parts) !== 2 || !hash_equals(hash_hmac('sha256', $parts[0], travelSecret()), $parts[1])) {
        throw new InvalidArgumentException('Please calculate your house-call distance before booking.');
    }
    $quote = json_decode((string) base64_decode($parts[0], true), true);
    if (!is_array($quote) || ($quote['location'] ?? '') !== $location || ($quote['expires'] ?? 0) < time()
        || !is_int($quote['meters'] ?? null) || $quote['meters'] < 0) {
        throw new InvalidArgumentException('Your address changed or the travel quote expired. Please calculate the distance again.');
    }
    return ['type' => $type, 'location' => $location, 'meters' => $quote['meters'], 'feeCents' => travelFeeCents($quote['meters'])];
}

function travelPaymentProof(string $reference, string $location, int $meters): string
{
    return hash_hmac('sha256', json_encode([$reference, $location, $meters]), travelSecret());
}

function travelDescription(array $travel): string
{
    if ($travel['type'] === 'dropoff') return 'Visit: Come to us. Travel charge: R0.00.';
    return 'Visit: House call. One-way driving distance: ' . number_format($travel['meters'] / 1000, 3, '.', '')
        . ' km at R5/km. Travel charge: R' . number_format($travel['feeCents'] / 100, 2, '.', '') . '.';
}
